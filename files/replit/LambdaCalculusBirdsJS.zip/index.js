// https://www.youtube.com/watch?v=3VQ382QG-y4
// https://www.youtube.com/watch?v=pAnLQ9jwN-E

I = a => a
M = f => f(f)
K = a => b => a

console.log(K(I)(M))
console.log(M(I))
//M(M)

console.log(K(I)(1)(2))

KI = a => b => b
C = f => a => b => f(b)(a)

console.log(C(K)(I)(M)) // KI(I)(M)
console.log(KI(I)(M))

const T = K
const F = KI

not = p => p(F)(T)

console.log(not(T))
console.log(not(F))

// alternative not: C flip
console.log(C(T)(1)(2))
console.log(C(F)(1)(2))

and2 = p => q => p(q)(p)

console.log(and2(T)(T))
console.log(and2(F)(T))

or2 = p => q => p(p)(q)

console.log(or2(T)(T))
console.log(or2(F)(T))
console.log(or2(F)(F))

or3 = p => q => M(p)(q) // ppq, M(p) = pp

console.log(or3(T)(T))
console.log(or3(F)(T))
console.log(or3(F)(F))

