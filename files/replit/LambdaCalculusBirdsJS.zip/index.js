// https://www.youtube.com/watch?v=3VQ382QG-y4
// https://www.youtube.com/watch?v=pAnLQ9jwN-E
// https://glebec.github.io/lambda-talk/

I = a => a
M = f => f(f)
K = a => b => a

console.log(K(I)(M))
console.log(M(I))
//M(M)

console.log(K(I)(1)(2))

KI = a => b => b
C = f => a => b => f(b)(a)

console.log(C(K)(I)(M)) // KI(I)(M)
console.log(KI(I)(M))

const T = K
const F = KI

not = p => p(F)(T)

console.log(not(T))
console.log(not(F))

// alternative not: C flip
console.log(C(T)(1)(2))
console.log(C(F)(1)(2))

and2 = p => q => p(q)(p)

console.log(and2(T)(T))
console.log(and2(F)(T))

or2 = p => q => p(p)(q)

console.log(or2(T)(T))
console.log(or2(F)(T))
console.log(or2(F)(F))

or3 = p => q => M(p)(q) // ppq, M(p) = pp

console.log(or3(T)(T))
console.log(or3(F)(T))
console.log(or3(F)(F))

// =========

// https://www.cnblogs.com/Answer1215/p/10844317.html
const jsnum = n => n(x => x + 1)(0);

n0 = f => a => a
n1 = f => a => f(a)
n2 = f => a => f(f(a))
n3 = f => a => f(f(f(a)))

succ = n => f => a => f(n(f)(a))

console.log(jsnum(succ(n0)))

B = f => g => a => f(g(a))

succB = n => f => B(f)(n(f))
console.log(jsnum(succB(n1)))

add = n => k => n(succ)(k)

console.log(jsnum(add(n2)(n3)))

mult = n => k => f => n(k(f))
multB = n => k => f => B(n)(k)(f)

console.log(jsnum(mult(n2)(n3)))
console.log(jsnum(multB(n2)(n3)))

pow = n => k => k(n)

console.log(jsnum(pow(n3)(n2)))

Th = a => f => f(a) // CI