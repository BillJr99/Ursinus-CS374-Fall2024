#ifndef _LIBS_H
#define _LIBS_H

#include <stdlib.h>

void *malloc(size_t size);
void free(void *ptr);

#endif