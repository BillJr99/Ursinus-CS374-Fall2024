// gcc main.c -ldl

#define _GNU_SOURCE // enable dlsym extensions such as RTLD_NEXT
#include "libs.h"
#include <dlfcn.h>
#include <stdio.h>

int main(void) {
  void *(*mallocp)(size_t size);
  
  void* lib = dlopen("./libs.so", RTLD_LAZY);
   
  mallocp = dlsym(lib, "malloc");

  int *x = (int *)mallocp(sizeof(int));
  *x = 5;
  printf("%d\n", *x);
  free(x);
}