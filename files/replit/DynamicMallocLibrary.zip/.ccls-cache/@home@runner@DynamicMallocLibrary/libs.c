// https://www.cs.cmu.edu/afs/cs/academic/class/15213-s16/www/lectures/12-linking.pdf
// gcc -Wall -DRUNTIME -shared -fpic -o libs.so libs.c -ldl

#define _GNU_SOURCE // enable dlsym extensions such as RTLD_NEXT
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>

/* mallocwrapper function */
void *malloc(size_t size) {
  void *(*mallocp)(size_t size);
  char *error;

  mallocp = dlsym(RTLD_NEXT, "malloc");

  /* Get addrof libcmalloc*/
  if ((error = dlerror()) != NULL) {
    fputs(error, stderr);
    exit(1);
  }

  char *ptr = mallocp(size);

  /* Call libcmalloc*/
  printf("malloc(%d) = %p\n", (int)size, ptr);
  return ptr;
}

/* free wrapper function */
void free(void *ptr) {
  void (*freep)(void *) = NULL;
  char *error;

  if (!ptr)
    return;

  freep = dlsym(RTLD_NEXT, "free");

  /* Get address of libcfree */
  if ((error = dlerror()) != NULL) {
    fputs(error, stderr);
    exit(1);
  }

  freep(ptr);

  /* Call libcfree */
  printf("free(%p)\n", ptr);
}