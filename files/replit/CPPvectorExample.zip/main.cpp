#include <iostream>
#include <memory>
#include <vector>

class Widget {
public:
  Widget(int id) : id(id) { std::cout << "Widget " << id << " created.\n"; }

  ~Widget() { std::cout << "Widget " << id << " destroyed.\n"; }

  void display() const { std::cout << "Widget ID: " << id << "\n"; }

private:
  int id;
};

int main() {
  // Create a vector to store shared_ptrs to Widgets
  std::vector<std::shared_ptr<Widget>> widgets;

  // Adding new Widgets to the vector using shared_ptr
  widgets.push_back(std::make_shared<Widget>(1));
  widgets.push_back(std::make_shared<Widget>(2));
  widgets.push_back(std::make_shared<Widget>(3));

  // Displaying all Widgets
  std::cout << "Displaying Widgets:\n";
  for (const auto &widgetPtr : widgets) {
    widgetPtr->display();
  }

  // Simulate shared ownership by copying a shared_ptr from the vector
  std::shared_ptr<Widget> anotherWidgetPtr = widgets[1];

  std::cout << "Removing the second Widget from the vector.\n";
  widgets.erase(widgets.begin() + 1);

  // Despite removing from the vector, the Widget object is still alive
  std::cout << "Widget in anotherWidgetPtr is still alive:\n";
  anotherWidgetPtr->display();

  std::cout << "Remaining Widgets in the vector:\n";
  for (const auto &widgetPtr : widgets) {
    widgetPtr->display();
  }

  // When main exits, all remaining Widgets will be destroyed as their
  // shared_ptr reference counts drop to zero.
  return 0;
}
