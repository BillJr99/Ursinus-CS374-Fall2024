#include <iostream>
#include <memory>

// Resource class with additional fields
class Resource {
public:
  int data;
  std::string name;

  Resource(int d, std::string n) : data(d), name(n) {
    std::cout << "Resource acquired: " << name << "\n";
  }
  ~Resource() { std::cout << "Resource destroyed: " << name << "\n"; }
};

// Function that manipulates the resource via a reference to the unique_ptr
void update_resource(std::unique_ptr<Resource> &res) {
  std::cout << "Manipulating resource: " << res->name << "\n";
  res->data += 10; // Modify the data field
  std::cout << "Updated data: " << res->data << "\n";
  res->name = "Updated " + res->name; // Modify the name field
  std::cout << "Updated name: " << res->name << "\n";
}

int main() {
  // Create a unique_ptr to a Resource object
  std::unique_ptr<Resource> resPtr =
      std::make_unique<Resource>(42, "TestResource");

  // Pass the unique_ptr by reference to a function that manipulates it
  // if you'd like resPtr to become deallocated and null after this call, you
  // can pass std::move(resPtr) instead, and not pass by reference; this
  // transfers ownership of the resource to the function
  update_resource(resPtr);

  // The resource can still be accessed in main
  std::cout << "Resource in main after update:\n";
  std::cout << "Name: " << resPtr->name << ", Data: " << resPtr->data << "\n";

  return 0;
}
