#include <chrono>
#include <iostream>

// note: set -fconstexpr-steps= in CXXFLAGS to set the number of constexpr
// compile steps, and -O0 to disable other compiler optimizations

// Regular function to calculate binomial coefficient
unsigned long long binomial_coeff_non_constexpr(int n, int k) {
  return (k == 0 || k == n) ? 1
                            : binomial_coeff_non_constexpr(n - 1, k - 1) +
                                  binomial_coeff_non_constexpr(n - 1, k);
}

// Constexpr function to calculate binomial coefficient
constexpr unsigned long long binomial_coeff_constexpr(int n, int k) {
  return (k == 0 || k == n) ? 1
                            : binomial_coeff_constexpr(n - 1, k - 1) +
                                  binomial_coeff_constexpr(n - 1, k);
}

int main() {
  int n = 25;
  int k = 15;
  constexpr int n_constexpr = 25;
  constexpr int k_constexpr = 15;

  // Timing non-constexpr version
  std::cout << "Testing non-constexpr version...\n";
  auto start_non_constexpr = std::chrono::high_resolution_clock::now();
  unsigned long long result_non_constexpr = binomial_coeff_non_constexpr(n, k);
  auto end_non_constexpr = std::chrono::high_resolution_clock::now();

  std::chrono::duration<double> elapsed_non_constexpr =
      end_non_constexpr - start_non_constexpr;
  std::cout << "Binomial Coefficient (non-constexpr) of " << n << " choose "
            << k << " is " << result_non_constexpr << "\n";
  std::cout << "Time taken: " << elapsed_non_constexpr.count() << " seconds\n";

  // Displaying constexpr result
  std::cout << "\nDisplaying constexpr result...\n";
  constexpr unsigned long long result_constexpr = binomial_coeff_constexpr(
      n_constexpr, k_constexpr); // Computed at compile-time
  std::cout << "Binomial Coefficient (constexpr) of " << n << " choose " << k
            << " is " << result_constexpr << "\n";
  std::cout << "Time taken: 0.0 seconds (computed at compile-time)\n";

  return 0;
}
