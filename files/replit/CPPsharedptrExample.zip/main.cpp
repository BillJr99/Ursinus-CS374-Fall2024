#include <iostream>
#include <memory>

// Resource class with additional fields
class Resource {
public:
  int data;
  std::string name;

  Resource(int d, std::string n) : data(d), name(n) {
    std::cout << "Resource acquired: " << name << "\n";
  }
  ~Resource() { std::cout << "Resource destroyed: " << name << "\n"; }
};

// Function that takes a shared_ptr and updates the resource
void update_resource_data(std::shared_ptr<Resource> res, int value) {
  std::cout << "Updating resource data in function 1...\n";
  res->data += value; // Modify the data field
  std::cout << "Data after update: " << res->data << "\n";
}

// Function that takes a shared_ptr and modifies the name
void update_resource_name(std::shared_ptr<Resource> res,
                          const std::string &newName) {
  std::cout << "Updating resource name in function 2...\n";
  res->name = newName; // Modify the name field
  std::cout << "Name after update: " << res->name << "\n";
}

int main() {
  std::shared_ptr<Resource> resPtr1;
  {
    // Block scope to show shared_ptr behavior
    std::shared_ptr<Resource> resPtr2 =
        std::make_shared<Resource>(42, "SharedResource");
    resPtr1 = resPtr2; // Now resPtr1 shares ownership with resPtr2

    // Pass resPtr2 to a function that updates the resource data
    update_resource_data(resPtr2, 10);

    // Block ends here, but resource is still alive because resPtr1 also owns it
  }

  // resPtr1 is still valid, even though resPtr2 has gone out of scope
  update_resource_name(resPtr1, "UpdatedResourceName");

  // Print the final state of the resource in main
  std::cout << "Final Resource state in main:\n";
  std::cout << "Name: " << resPtr1->name << ", Data: " << resPtr1->data << "\n";

  return 0;
}
