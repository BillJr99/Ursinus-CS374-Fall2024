ENROLLMENTS='CS374,18'
ENROLLMENTS=${ENROLLMENTS}$'\n'
ENROLLMENTS=${ENROLLMENTS}"CS475,20"

for line in $ENROLLMENTS
do
  NUMSTUDENTS=`echo ${line} | cut -f2 -d,`
  COURSE=`echo ${line} | cut -f1 -d,`
  NUMSTUDENTS=`echo ${line} | awk '{split($0,tokens,","); print tokens[2]}'`
  COURSE=`echo ${line} | awk '{split($0,tokens,","); print tokens[1]}'`
  echo In $COURSE there are $NUMSTUDENTS enrolled.
done