from functools import reduce

# Sample dataset: a list of dictionaries
people = [
    {"name": "Alice", "age": 28, "salary": 50000},
    {"name": "Bob", "age": 34, "salary": 60000},
    {"name": "Charlie", "age": 22, "salary": 40000},
    {"name": "Diana", "age": 30, "salary": 70000},
]

# Functional pipeline

# 1. Filter out people younger than 30
filter_adults = lambda person: person["age"] >= 30
adults = filter(filter_adults, people)

# 2. Map the remaining people's salaries to reflect a 10% raise
raise_salary = lambda person: {**person, "salary": person["salary"] * 1.10}
updated_salaries = map(raise_salary, adults)

# 3. Reduce to calculate the total salary of all remaining people
sum_salaries = lambda acc, person: acc + person["salary"]
total_salary = reduce(sum_salaries, updated_salaries, 0)

# Output the total salary
print("Total salary after raises:", total_salary)
