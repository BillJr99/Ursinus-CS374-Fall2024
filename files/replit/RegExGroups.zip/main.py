# https://stackoverflow.com/questions/12870178/looping-through-python-regex-matches
import re

s = "ABC12DEF3G56HIJ7"
pattern = re.compile(r'([A-Z]+)([0-9]+)')

groups = re.findall(pattern, s)

print(dir(groups[0]))

for i in range(len(groups)):
  print("GROUP {}".format(i))

  for j in range(len(groups[i])):
    print(groups[i][j])