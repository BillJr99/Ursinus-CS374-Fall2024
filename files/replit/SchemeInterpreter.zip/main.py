from enum import Enum
import uuid

namespace_split = "/"


# https://stackoverflow.com/questions/736043/checking-if-a-string-can-be-converted-to-float-in-python
def is_float(element):
    try:
        float(element)
        return True
    except ValueError:
        return False


class Token(Enum):
    DEFINE = 0
    LAMBDA = 1
    IF = 2
    ISNULL = 3
    CAR = 4
    CDR = 5
    LIST = 6


nametable = {}


def tokenize(tokens, start=0):
    stmt = []

    i = start
    done = False
    while i < len(tokens) and not done:
        newi = i + 1

        tokens[i] = tokens[i].strip()

        if len(tokens[i]) > 0:
            if tokens[i] == '(':
                innerstmt, newi = tokenize(tokens, i + 1)
                stmt.append(innerstmt)
            elif tokens[i] == "define":
                stmt.append(Token.DEFINE)
            elif tokens[i] == "lambda":
                stmt.append(Token.LAMBDA)
            elif tokens[i] == "if":
                stmt.append(Token.IF)
            elif tokens[i] == "null?":
                stmt.append(Token.ISNULL)
            elif tokens[i] == "car":
                stmt.append(Token.CAR)
            elif tokens[i] == "cdr":
                stmt.append(Token.CDR)
            elif tokens[i] == "list":
                stmt.append(Token.LIST)
            elif tokens[i] == ")":
                done = True
            else:
                stmt.append(tokens[i])

        i = newi

    return stmt, i


def lookup(symbol, namespace=""):
    print(nametable)
  
    val = None

    if len(namespace) > 0:
        symbolname = namespace + namespace_split + symbol
        if symbolname in nametable:
            val = nametable[symbolname]
        else:
            val = nametable[symbol]
    else:
        val = nametable[symbol]

    return val


def insert(symbol, val, namespace=""):
    if len(namespace) > 0:
        nametable[namespace + namespace_split + symbol] = val
    else:
        nametable[symbol] = val


def parse(program, start=0, namespace=""):
    i = start
    retval = None
    while i < len(program):
        newi = i + 1
        statement = program[i]
        if statement == Token.DEFINE:
            keyword = program[i + 1]
            value = program[i + 2]
            newi = i + 3
            retval = parse(value, namespace=namespace)
            insert(keyword, retval, namespace)
        elif statement == Token.LAMBDA:
            params = program[i + 1]
            code = program[i + 2]
            newi = i + 3
            retval = [Token.LAMBDA, params, code]
        elif statement == Token.IF:
            condition = program[i + 1]
            iftrue = program[i + 2]
            iffalse = program[i + 3]
            newi = i + 4
            result = parse(condition, namespace=namespace)
            if result:
                retval = parse(iftrue, namespace=namespace)
            else:
                retval = parse(iffalse, namespace=namespace)
        elif statement == Token.ISNULL:
            condition = program[i + 1]
            newi = i + 2
            result = parse(condition, namespace=namespace)
            if (result is None):
                retval = True
            else:
                retval = False
        elif statement == Token.CAR:
            listname = program[i + 1]
            listval = lookup(listname, namespace)
            newi = i + 2
            if len(listval) > 0:
                retval = listval[0]
            else:
                retval = None
        elif statement == Token.CDR:
            listname = program[i + 1]
            listval = lookup(listname, namespace)
            newi = i + 2
            if len(listval) > 1:
                retval = listval[1:]
            else:
                retval = None
        elif statement == Token.LIST:
            newi = i + 2
            retval = program[i + 1]
        else:
            symbol = statement
            if symbol == '+':
                op1 = program[i + 1]
                op2 = program[i + 2]
                newi = i + 3
                retval = float(parse(op1, namespace=namespace)) + float(
                    parse(op2, namespace=namespace))
            elif is_float(symbol):
                newi = i + 1
                retval = float(symbol)
            else:
                retval = lookup(symbol, namespace)
                newi = i + 1
                if isinstance(retval, list):
                    if retval[0] == Token.LAMBDA:
                        params = retval[1]
                        code = retval[2]
                        localnamespace = str(uuid.uuid4())
                        for j in range(len(params)):
                            param = params[j]
                            value = parse(program[i + j + 1],
                                          namespace=namespace)
                            insert(param, value, localnamespace)

                        retval = parse(code, namespace=localnamespace)

                        newi = i + len(params) + 1

        i = newi

        if not retval is None:
            return retval


fname = 'input.txt'

f = open(fname, 'r')
data = f.read().replace('\n', ' ').replace('(', ' ( ').replace(')', ' ) ')

code = data.strip()
tokens = code.split(" ")
program, position = tokenize(tokens)
print(program)
print()
for statement in program:
    retval = parse(statement)
    print(retval)
    print()
