from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import reduce
import operator

# A pure function that does not depend on or modify shared state
def factorial(n):
    return reduce(operator.mul, range(1, n + 1), 1)

# Another pure function that computes the sum of a list of numbers
def sum_of_factorials(numbers):
    return sum(map(factorial, numbers))

def main():
    # List of numbers to compute the factorial of
    numbers = [5, 7, 10, 12, 15]

    # Using ThreadPoolExecutor for concurrent execution
    with ThreadPoolExecutor(max_workers=4) as executor:
        # Submit tasks to the thread pool
        futures = {executor.submit(factorial, n): n for n in numbers}

        results = {}
        for future in as_completed(futures):
            n = futures[future]
            try:
                result = future.result()
                results[n] = result
            except Exception as exc:
                print(f"Factorial of {n} generated an exception: {exc}")

    # Compute the sum of all factorials
    total_sum = sum_of_factorials(numbers)

    print("Factorials:", results)
    print("Sum of factorials:", total_sum)

if __name__ == "__main__":
    main()
